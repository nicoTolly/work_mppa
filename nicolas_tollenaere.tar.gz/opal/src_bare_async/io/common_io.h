#ifndef __COMMON_IO_H__
#define __COMMON_IO_H__

#ifdef MPPA_ASYNC_BOOST
	#define NB_RM 4
#else 
	#define NB_RM 1
#endif

#endif // __COMMON_IO_H__
